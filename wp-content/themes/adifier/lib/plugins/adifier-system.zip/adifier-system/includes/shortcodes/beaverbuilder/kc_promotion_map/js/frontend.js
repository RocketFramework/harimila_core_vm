jQuery(document).ready(function($){
	$(document).trigger('kc_promotion_map-js-trigger');
});