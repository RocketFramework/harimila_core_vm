<?php
if( !class_exists('Adifier_Elementor_kc_price_tables') ){
class Adifier_Elementor_kc_price_tables extends Adifier_Elementor_Base {

}
}
?>