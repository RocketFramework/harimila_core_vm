jQuery(document).ready(function($){
	$(document).trigger('kc_categories-js-trigger');
});