<?php
if( !class_exists('Adifier_Elementor_kc_quick_search') ){
class Adifier_Elementor_kc_quick_search extends Adifier_Elementor_Base {

}
}
?>