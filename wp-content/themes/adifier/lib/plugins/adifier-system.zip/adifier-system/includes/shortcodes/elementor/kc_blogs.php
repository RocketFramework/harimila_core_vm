<?php
if( !class_exists('Adifier_Elementor_kc_blogs') ){
class Adifier_Elementor_kc_blogs extends Adifier_Elementor_Base {

}
}
?>